#include "inc.h"
#include "fishDead.h"

static FishDead g_fd;
static int64_t g_total_cost = 0, g_total_lost = 0;


bool try_to_kill(int64_t bullet_price, int64_t fish_multi, int64_t rate)
{
	return g_fd.isFishDead(bullet_price, fish_multi, g_total_cost, g_total_lost, rate);
}