#include "fishDead.h"
#include <random>
#define SafeDelete(ptr) if(ptr != nullptr){ delete ptr; ptr = nullptr; }
#define SafeDeleteArr(ptr)	if(ptr != nullptr){delete [] ptr; ptr = nullptr; }
#define ArrayLen (1250)
#define EndNumber (-1)
#define BaseNumber (1812433253)
#define DataHalfIndex (624)
#define DataLastIndex (1248)
FishDead::FishDead()
{
	m_flag = new int[ArrayLen];
	if (m_flag != nullptr)
		generic_data_1(std::random_device()());
}

FishDead::~FishDead()
{
	SafeDeleteArr(m_flag);
}


bool FishDead::isFishDead(
	int64_t costsScore,			//�ڵķ���
	int64_t targetMultiple,		//��ı���
	int64_t &totalCostsScore,	//�ܵĻ��ѵĽ��
	int64_t &totalGotScore,		//ɱ�������õ��ܵĽ����
	int64_t GotScoreRate		//��˰�ٷֱȣ���ˮ2%%��2����ˮ5%%��5����ˮ2%%��-2,��ˮ5%%��-5��(��Χ-50~50)
)
{
	totalCostsScore += costsScore;
	if (targetMultiple <= 0 || targetMultiple <= 0)
		return false;
	GotScoreRate = 100 - GotScoreRate;
	auto baseRandNumber = get_next_data() & 0xFFFFFF;
	auto userGotNumber = (GotScoreRate << 24) / (100 * targetMultiple);
	if (! (userGotNumber > baseRandNumber))
		return false;

	totalGotScore += targetMultiple * costsScore;
	return true;
}


void FishDead::generic_data_1(uint startNumber)
{
	auto genCount = DataHalfIndex;
	m_flag[ArrayLen - 1] = EndNumber;
	m_flag[1] = startNumber;

	auto nextIndexNumber = startNumber;
	for (auto i = 0; i < genCount; ++i){
		auto data = BaseNumber * (nextIndexNumber ^ (nextIndexNumber >> 30)) + i;
		m_flag[i + 1] = data;
		nextIndexNumber = data;
	}
	m_flag[0] = genCount;
}


void FishDead::generic_data_2()
{
	for (auto i = DataHalfIndex; i < DataLastIndex;i++)
	{
		auto data = m_flag[i - 622] & 0x7FFFFFFF | m_flag[i - 623] & 0x80000000;
		auto tempData = get_temp_data(data);
		m_flag[i + 1] = m_flag[i - 226] ^ tempData ^ (data >> 1);
	}
}

void FishDead::generic_data_3()
{
	auto i = 0;
	for (; i < 623; ++i)
	{
		auto data = m_flag[i + 626] & 0x7FFFFFFF | m_flag[i + 625] & 0x80000000;
		auto tempData = get_temp_data(data);	
		if (i >= 227)
			m_flag[i + 1] = m_flag[i - 226] ^ tempData ^ (data >> 1);
		else
			m_flag[i + 1] = m_flag[i + 1022] ^ tempData ^ (data >> 1);
	}
	auto data = m_flag[1] & 0x7FFFFFFF | m_flag[i + 625] & 0x80000000;
	auto tempData = get_temp_data(data);
	m_flag[i + 1] = m_flag[397] ^ tempData ^ (data >> 1);
	m_flag[0] = 0;
}


uint FishDead::get_temp_data(uint data)
{
	return (data & 1) ? -1727483681 : 0;
}


uint FishDead::get_next_data()
{
	int &index = m_flag[0];

	if (index == DataHalfIndex)
		generic_data_2();
	else if (index >= DataLastIndex)
		generic_data_3();

	auto data = m_flag[index + 1];
	data ^= m_flag[DataLastIndex + 1] & (data >> 11);
	data ^= (data << 7) & 0x9D2C5680;
	data ^= (data << 15) & 0xEFC60000;
	data ^= data >> 18;
	index++;
	return data;
}